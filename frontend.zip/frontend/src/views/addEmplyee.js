import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import {
  Container,
  Grid,
  Typography,
  TextField,
  Button,
  Box,
  Alert,
} from "@mui/material";
import axios from "axios";

export default function SimpleContainer() {
  const navigate = useNavigate();
  const [alert, setalert] = useState({
    visible: false,
    msg: "",
    type: "success",
  });
  const [state, setstate] = useState({
    firstname: "",
    lastname: "",
    email: "",
  });

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const submitUser = await axios.post(
        "http://localhost:9090/api/v1/employees",
        state
      );
      setalert({
        ...alert,
        visible: true,
        msg: submitUser.data.message,
        type: "success",
      });
      setstate({ firstname: "", lastname: "", email: "" });
    } catch (error) {
      if (error.response.data) {
        return setalert({
          ...alert,
          visible: true,
          msg: error.response.data.message,
          type: "error",
        });
      }
      console.log(error);
    }
  };
  return (
    <Container maxWidth="sm">
      <Grid container padding="15px">
        <Grid
          item
          display="flex"
          alignItems="center"
          justifyContent="space-between"
          xs={12}
        >
          <Typography variant="h5">Add Employee</Typography>
          <Button onClick={() => navigate("/")} variant="contained">
            View All
          </Button>
        </Grid>
        <Grid item xs={12} marginTop="30px">
          {alert.visible && (
            <Alert
            
              severity={alert.type}
              onClose={() => setalert({ ...alert, visible: false })}
            >
              {alert.msg}
            </Alert>
          )}
          <Box onSubmit={handleSubmit} component="form" Validate>
            <TextField
              id="first-name"
              label="First Name"
              variant="outlined"
              value={state.firstname}
              margin="normal"
              fullWidth
              onChange={(e) =>
                setstate({ ...state, firstname: e.target.value })
              }
              required
            />
            <TextField
              id="last-name"
              label="Last Name"
              variant="outlined"
              fullWidth
              margin="normal"
              value={state.lastname}
              required
              onChange={(e) => setstate({ ...state, lastname: e.target.value })}
            />
            <TextField
              id="email"
              type="email"
              margin="normal"
              fullWidth
              label="Email"
              variant="outlined"
              value={state.email}
              required
              onChange={(e) => setstate({ ...state, email: e.target.value })}
            />
            <Button
              style={{ minHeight: "56px", marginTop: "15px" }}
              type="submit"
              fullWidth
              variant="outlined"
            >
              Add Emplyee
            </Button>
          </Box>
        </Grid>
      </Grid>
    </Container>
  );
}
