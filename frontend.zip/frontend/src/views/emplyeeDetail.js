/* eslint-disable react-hooks/exhaustive-deps */
import React, { useState, useEffect } from "react";
import { useNavigate, useParams } from "react-router-dom";
import {
  Container,
  Grid,
  Typography,
  Button,
  Box,
} from "@mui/material";
import axios from "axios";

export default function SimpleContainer() {
  const navigate = useNavigate();
  const params = useParams();
  const [state, setstate] = useState();

  useEffect( async () => {
    try {
      const {data} = await axios.get(`http://localhost:9090/api/v1/employees/${params.id}`)
      setstate(data)
    } catch (error) {
      navigate('/')
      console.log(error)
    }
  },[params])
  return (
    <Container maxWidth="sm">
      <Grid container padding="15px">
        <Grid
          item
          display="flex"
          alignItems="center"
          justifyContent="space-between"
          xs={12}
        >
          <Typography variant="h5">Employee Detail</Typography>
          <Button onClick={() => navigate("/")} variant="contained">
            View All
          </Button>
        </Grid>
        <Grid item xs={12} marginTop="30px">
          <Box border='1px solid gray' padding='20px'>
              <Typography marginBottom='15px' display='flex' gap='50px' variant='h6'><strong>First Name:</strong>  <span>{state?.firstname}</span></Typography>
              <Typography marginBottom='15px' display='flex' gap='50px' variant='h6'><strong>Last Name:</strong>  <span>{state?.lastname}</span></Typography>
              <Typography marginBottom='15px' display='flex' gap='50px' variant='h6'><strong>Email:</strong>  <span>{state?.email}</span></Typography>
          </Box>
        </Grid>
      </Grid>
    </Container>
  );
}
